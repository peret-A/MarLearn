package com.bdqn.utils;

import com.bdqn.entity.Clazz;
import com.bdqn.entity.Course;
import com.bdqn.entity.Student;
import com.bdqn.entity.Teacher;

import java.util.Date;
import java.util.Scanner;

public class CreateClassUtils {
/**
 * @author liuziyang
 * @data 2024-03-09-8:39
 */
    //创建类
    public static Course createCourse(){
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        System.out.print("请输入课程号: ");
        int cno = scanner.nextInt();
        System.out.print("请输入课程名称: ");
        String cname = scanner.next();
        System.out.print("请输入课程教师: ");
        int tno = scanner.nextInt();
        Course course =new Course(cno,cname,tno);
        return course;
    }
    public static Clazz createClazz(){
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        System.out.print("请输入班级号: ");
        int classno = scanner.nextInt();
        System.out.print("请输入班主任名称: ");
        int tno = scanner.nextInt();
        System.out.print("请输入班级名称: ");
        String classname = scanner.next();
        Clazz clazz =new Clazz(classno,tno,classname);
        return clazz;
    }
    public static Teacher createTeacher(){
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        System.out.print("请输入教师名字: ");
        String tname = scanner.next();
        System.out.print("请输入教师性别(男/女): ");
        String tsex = scanner.next();
        if(!tsex.equals("男"))
            tsex = "女";
        System.out.print("请输入教师生日(yyyy-MM-dd): ");
        Date tbirthday = DateUtils.strToUtilDate(scanner.next());
        System.out.print("请输入教师职称: ");
        String prof = scanner.next();
        System.out.print("请输入教师系别: ");
        String depart = scanner.next();
        System.out.print("请输入教师用户名: ");
        String username = scanner.next();
        System.out.print("请输入教师密码: ");
        String passwrod = scanner.next();
        Teacher teacher = new Teacher(tname,tsex,tbirthday,prof,depart,username,passwrod);
        return teacher;
    }
    public static Teacher createTeacherAll(){
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        Teacher teacher =createTeacher();
        System.out.print("请输入要修改的教师号: ");
        teacher.setTno(scanner.nextInt());
        return teacher;
    }

    public static Student createStudent(){
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        System.out.print("请输入学生名字: ");
        String tname = scanner.next();
        System.out.print("请输入学生性别(男/女): ");
        String tsex = scanner.next();
        if(!tsex.equals("男"))
            tsex = "女";
        System.out.print("请输入学生生日(yyyy-MM-dd): ");
        Date tbirthday = DateUtils.strToUtilDate(scanner.next());
        System.out.print("请输入学生班级号: ");
        int classno = scanner.nextInt();
        System.out.print("请输入学生用户名: ");
        String username = scanner.next();
        System.out.print("请输入学生密码: ");
        String passwrod = scanner.next();
        Student student = new Student(tname,tsex,tbirthday,classno,username,passwrod);
        return student;
    }
    public static Student createStudentAll(){
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        Student student =createStudent();
        System.out.print("请输入要修改的学号: ");
        student.setSno(scanner.nextInt());
        return student;
    }
}

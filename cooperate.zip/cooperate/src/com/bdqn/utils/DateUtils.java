package com.bdqn.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtils {
/**
 * @author liuziyang
 * @data 2024-03-07-10:56
 */
private  final static SimpleDateFormat SIMPLEDATEFORMAT = new SimpleDateFormat("yyyy-MM-dd");
    //将字符串转换成java.util.date
    public static Date strToUtilDate(String strDate){
        try {
            Date date= SIMPLEDATEFORMAT.parse(strDate);
            return  date;
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }
    //将java.util.date转换成str
    public static String utilDateToString(Date date){
        return SIMPLEDATEFORMAT.format(date);
    }
    //将java.util.date转换成java.sql.date
    public static java.sql.Date utilDateToSqlDate(Date date){
        return new java.sql.Date(date.getTime());
    }
}

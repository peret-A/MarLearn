package com.bdqn.utils;

import com.alibaba.druid.pool.DruidAbstractDataSource;
import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidDataSourceFactory;

import javax.sql.DataSource;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class DBUtils {
/**
 * @author liuziyang
 * @data 2024-03-08-9:07
 */
//声明连接池对象
    private  static  DruidDataSource druidDataSource;

    //定义静态代码块去配置文件
    static {
        //实例化配置文件
        Properties properties =new Properties();
        try {
            //加载文件内容
            InputStream inputStream =DBUtils.class.getResourceAsStream("/db.properties");
            properties.load(inputStream);
            //创建连接池
            druidDataSource = (DruidDataSource) DruidDataSourceFactory.createDataSource(properties);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }
    //定义静态方式去注册驱动 返回数据库链接对象
    public static Connection getConnection(){
        try {
            return druidDataSource.getConnection();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    //定义静态方法去释放资源
    public static void closeAll(Connection connection , Statement statement , ResultSet resultSet){
        if(resultSet!=null){
            try {
                resultSet.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }

        }
        if(statement!=null){
            try {
                statement.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
        if(connection!=null){
            try {
                //此时不是关闭数据库链接对象 而是将对象返回连接池中
                connection.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }
    //定义一个静态方法返回数据库连接池
    public static DataSource getDatabase(){
        return druidDataSource;
    }



    // 开启事务
    public static void startTransaction() {
        Connection connection = null;
        try {
            connection = getConnection();
            connection.setAutoCommit(false);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 提交事务
    public static void commitTransaction() {
        Connection connection = getConnection();
        try {
            connection.commit();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtils.closeAll(connection, null, null);
        }
    }

    // 回滚事务
    public static void rollbackTransaction() {
        Connection connection = getConnection();
        try {
            connection.rollback();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtils.closeAll(connection, null, null);
        }
    }
}

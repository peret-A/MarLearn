package com.bdqn.utils;

import com.bdqn.entity.Manage;
import com.bdqn.entity.Student;
import com.bdqn.entity.Teacher;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import java.sql.SQLException;
import java.util.Scanner;

public class VerifyUtils {
/**
 * @author liuziyang
 * @data 2024-03-09-10:32
 */
    //管理员在用户名字段前+ 管理员 字符
    //教师在用户名字段前+ 教师 字符
    //学生在用户名字段前+ 学生 字符、
    //做加密 避免不同身份之间因用户名相同而进入错误页面
//创建apache的工具类QueryRunner
private  static QueryRunner queryRunner =new QueryRunner(DBUtils.getDatabase());
    //用于验证登录
    public static Manage verifyManage(){
        //创建Scanner 对象
        Scanner scanner =new Scanner(System.in);
        System.out.print("输入用户名: ");
        String username = "管理员"+scanner.next();
        System.out.print("输入密码: ");
        String password = scanner.next();
        //定义sql
        String sql = "select * from manage where username = ? and password = ?";
        BeanHandler<Manage> beanHandler = new BeanHandler<>(Manage.class);
        //给占位符赋值
        Object[] args = {username,password};
        //调用query方法
        try {
            return queryRunner.query(sql,beanHandler,args);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }
    public static Teacher verifyTeacher(){
        //创建Scanner 对象
        Scanner scanner =new Scanner(System.in);
        System.out.print("输入用户名: ");
        String username = "教师"+scanner.next();
        System.out.print("输入密码: ");
        String password = scanner.next();
        //定义sql
        String sql = "select * from teacher where username = ? and password = ?";
        BeanHandler<Teacher> beanHandler = new BeanHandler<>(Teacher.class);
        //给占位符赋值
        Object[] args = {username,password};
        //调用query方法
        try {
            return queryRunner.query(sql,beanHandler,args);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }
    public static Student verifyStudent(){
        //创建Scanner 对象
        Scanner scanner =new Scanner(System.in);
        System.out.print("输入用户名: ");
        String username = "学生"+scanner.next();
        System.out.print("输入密码: ");
        String password = scanner.next();
        //定义sql
        String sql = "select * from student where username = ? and password = ?";
        BeanHandler<Student> beanHandler = new BeanHandler<>(Student.class);
        //给占位符赋值
        Object[] args = {username,password};
        //调用query方法
        try {
            return queryRunner.query(sql,beanHandler,args);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
}
}

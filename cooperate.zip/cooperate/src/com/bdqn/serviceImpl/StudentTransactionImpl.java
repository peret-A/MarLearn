package com.bdqn.serviceImpl;

import com.bdqn.dao.StudentDao;
import com.bdqn.daoImpl.StudentDaoImpl;
import com.bdqn.entity.Score;
import com.bdqn.entity.Student;
import com.bdqn.service.StudentTransaction;
import com.bdqn.utils.CreateClassUtils;

import java.util.List;
import java.util.Scanner;

public class StudentTransactionImpl implements StudentTransaction {
    private StudentDao studentDao =new StudentDaoImpl();
    //--------------------------------------------------------------------------------
    //关于自己操作
    @Override
    public void check(Student student) {
        //调用dao包实现类的select方法
        Student student1 =studentDao.select(student);
        if(student1!=null){
            System.out.println(student1);
        }else{
            System.out.println("未查找数据");
        }
    }

    @Override
    public void update(Student student) {
        int sno = student.getSno();
        //创建Student对象
        student=CreateClassUtils.createStudentAll();
        student.setSno(sno);
        //调用dao包实现类的update方法
        int num =studentDao.update(student);
        System.out.println(num == 0?"修改失败":"修改成功");
    }

    @Override
    public void delete(Student student) {
        //调用dao包实现类的delete方法
        int num =studentDao.delete(student);
        System.out.println(num == 0?"删除失败":"删除成功");
    }
    //--------------------------------------------------------------------------------
    //关于成绩操作
    @Override
    public void checkScoreAll(Student student) {
        //调用dao包实现类的checkScoreAll方法
        List<Score> scoreList =studentDao.checkScoreAll(student);
        if(!scoreList.isEmpty()){
            //遍历集合
            for(Score score:scoreList){
                System.out.println(score);
            }
        }else{
            System.out.println("未查找数据");
        }
    }

    @Override
    public void checkScoreBycno(Student student) {
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        System.out.print("请输入要查询的课程号: ");
        int cno = scanner.nextInt();

        //调用dao包实现类的checkScoreAll方法
        Score score =studentDao.checkScoreByCno(student,cno);
        if(score!=null){
            System.out.println(score);
        }else{
            System.out.println("未查找数据");
        }
    }

    @Override
    public void checkScoreByClassno(Student student) {
        //调用dao包实现类的checkClassScoreByClassno方法
        List<Score> scoreList =studentDao.checkClassScoreByClassno(student);
        if(!scoreList.isEmpty()){
            //遍历集合
            for(Score score:scoreList){
                System.out.println(score);
            }
        }else{
            System.out.println("未查找数据");
        }
    }

    @Override
    public void checkScoreByClassnoCno(Student student) {
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        System.out.print("请输入要查询的课程号: ");
        int cno = scanner.nextInt();

        //调用dao包实现类的checkClassScoreByClassno方法
        List<Score> scoreList =studentDao.checkClassScoreByCno(student,cno);
        if(!scoreList.isEmpty()){
            //遍历集合
            for(Score score:scoreList){
                System.out.println(score);
            }
        }else{
            System.out.println("未查找数据");
        }
    }

    @Override
    public void checkScoreBySno(Student student) {
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        System.out.print("请输入要查询的学号: ");
        int sno = scanner.nextInt();

        //调用dao包实现类的checkClassScoreByClassno方法
        List<Score> scoreList =studentDao.checkOtherScoreBySno(student,sno);
        if(!scoreList.isEmpty()){
            //遍历集合
            for(Score score:scoreList){
                System.out.println(score);
            }
        }else{
            System.out.println("未查找数据");
        }
    }

    @Override
    public void checkScoreBySnoCno(Student student) {
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        System.out.print("请输入要查询的学号: ");
        int sno = scanner.nextInt();
        System.out.print("请输入要查询的课程号: ");
        int cno = scanner.nextInt();

        //调用dao包实现类的checkClassScoreByClassno方法
        Score score =studentDao.checkOtherScoreBySnoCno(student,sno,cno);
        if(score!=null){
            System.out.println(score);
        }else{
            System.out.println("未查找数据");
        }
    }
/**
 * @author liuziyang
 * @data 2024-03-09-10:25
 */

}

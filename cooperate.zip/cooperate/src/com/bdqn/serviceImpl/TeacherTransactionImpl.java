package com.bdqn.serviceImpl;

import com.bdqn.dao.TeacherDao;
import com.bdqn.dao.TeacherStudentDao;
import com.bdqn.daoImpl.TeacherDaoImpl;
import com.bdqn.daoImpl.TeacherStudentDaoImpl;
import com.bdqn.entity.Score;
import com.bdqn.entity.Student;
import com.bdqn.entity.Teacher;
import com.bdqn.service.TeacherTransaction;
import com.bdqn.utils.CreateClassUtils;

import java.util.List;
import java.util.Scanner;

public class TeacherTransactionImpl implements TeacherTransaction {
/**
 * @author liuziyang
 * @data 2024-03-09-14:23
 */
//对自己
private TeacherDao teacherDao =new TeacherDaoImpl();
private TeacherStudentDao teacherStudentDao =new TeacherStudentDaoImpl();


    @Override
    public void check(Teacher teacher) {
        Teacher teacher1 = teacherDao.select(teacher);
        if(teacher1!=null){
            System.out.println(teacher1);
        }else{
            System.out.println("未查找数据");
        }
    }

    @Override
    public void update(Teacher teacher) {
        int tno = teacher.getTno();
        //创建新的教师
        teacher = CreateClassUtils.createTeacher();
        teacher.setTno(tno);
        int num = teacherDao.update(teacher);
        System.out.println(num == 0?"修改失败":"修改成功");
    }

    @Override
    public void delete(Teacher teacher) {
        int num =teacherDao.delete(teacher);
        System.out.println(num == 0?"修改失败":"修改成功");
    }

    @Override
    public void checkStudentAll(Teacher teacher) {
        List<Student> studentList =teacherStudentDao.selectStudentAll(teacher);
        if(!studentList.isEmpty()){
            //遍历集合
            for(Student student:studentList){
                System.out.println(student);
            }
        }else{
            System.out.println("未查找数据");
        }
    }

    @Override
    public void checkStudentBySno(Teacher teacher) {
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        System.out.print("请输入要查询的学号: ");
        int sno = scanner.nextInt();


        Student student =teacherStudentDao.selectStudentBySno(teacher,sno);
        if(student!=null){
            System.out.println(student);
        }else{
            System.out.println("未查找数据");
        }
    }

    @Override
    public void insertStudent(Teacher teacher) {
        //创建Student对象
        Student student =CreateClassUtils.createStudent();


        int num =teacherStudentDao.insertStudent(teacher,student);
        System.out.println(num == 0?"插入失败":"插入成功");
    }

    @Override
    public void updateStudent(Teacher teacher) {
        //创建Student对象
        Student student =CreateClassUtils.createStudentAll();


        int num =teacherStudentDao.updateStudent(teacher,student);
        System.out.println(num == 0?"修改失败":"修改成功");
    }

    @Override
    public void deleteStudent(Teacher teacher) {
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        System.out.print("请输入要查询的学号: ");
        int sno = scanner.nextInt();


        int num =teacherStudentDao.deleteStudent(teacher,sno);
        System.out.println(num == 0?"删除失败":"删除成功");
    }

    @Override
    public void checkScoreAll(Teacher teacher) {
        List<Score> scoreList =teacherStudentDao.selectScoreAll(teacher);
        if(!scoreList.isEmpty()){
            //遍历集合
            for(Score score:scoreList){
                System.out.println(score);
            }
        }else{
            System.out.println("未查找数据");
        }
    }

    @Override
    public void checkScoreByCno(Teacher teacher) {
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        System.out.print("请输入要查询的课程号: ");
        int cno = scanner.nextInt();

        List<Score> scoreList =teacherStudentDao.selectScoreByCno(teacher,cno);
        if(!scoreList.isEmpty()){
            //遍历集合
            for(Score score:scoreList){
                System.out.println(score);
            }
        }else{
            System.out.println("未查找数据");
        }
    }

    @Override
    public void checkScoreBySno(Teacher teacher) {
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        System.out.print("请输入要查询的学号: ");
        int sno = scanner.nextInt();

        List<Score> scoreList =teacherStudentDao.selectScoreBySno(teacher,sno);
        if(!scoreList.isEmpty()){
            //遍历集合
            for(Score score:scoreList){
                System.out.println(score);
            }
        }else{
            System.out.println("未查找数据");
        }
    }

    @Override
    public void checkScoreBySnoCno(Teacher teacher) {
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        System.out.print("请输入要查询的学号: ");
        int sno = scanner.nextInt();
        System.out.print("请输入要查询的课程号: ");
        int cno = scanner.nextInt();

        Score score =teacherStudentDao.selectScoreByTnoSnoCno(teacher,sno,cno);
        if(score!=null){
            System.out.println(score);
        }else{
            System.out.println("未查找数据");
        }
    }
}

package com.bdqn.serviceImpl;

import com.bdqn.dao.*;
import com.bdqn.daoImpl.*;
import com.bdqn.entity.*;
import com.bdqn.service.ManageTransaction;
import com.bdqn.utils.CreateClassUtils;

import java.util.List;
import java.util.Scanner;

public class ManageTransactionImpl implements ManageTransaction {
    private ManageClazzDao manageClazzDao =new ManageClazzDaoImpl();
    private  ManageCourseDao manageCourseDao = new ManageCourseDaoImpl();
    private ManageTeacherDao manageTeacherDao =new ManageTeacherDaoImpl();
    private ManageStudentDao manageStudentDao =new ManageStudentDaoImpl();
    private ManageScoreDao manageScoreDao =new ManageScoreDaoImpl();
    //--------------------------------------------------------------------------------
    //关于班级操作
    @Override
    public void checkClazzAll() {
        //调用dao包实现类的selectall方法
        List<Clazz> clazzList =manageClazzDao.selectAll();
        if(!clazzList.isEmpty()){
            //遍历集合
            for(Clazz clazz:clazzList){
                System.out.println(clazz);
            }
        }else{
            System.out.println("未查找数据");
        }
    }

    @Override
    public void checkClazzByClassno() {
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        System.out.print("请输入要查询的班级号: ");
        int classno = scanner.nextInt();

        //调用dao包实现类的selectByClassno方法
        Clazz clazz =manageClazzDao.selectByClassno(classno);
        if(clazz!=null){
            System.out.println(clazz);
        }else{
            System.out.println("未查找数据");
        }
    }

    @Override
    public void updateClazz() {
        //创建Clazz对象
        Clazz clazz = CreateClassUtils.createClazz();
        //调用dao包实现类的update方法
        int num = manageClazzDao.update(clazz);
        System.out.println(num == 0?"修改失败":"修改成功");
    }

    @Override
    public void insertClazz() {
        //创建Clazz对象
        Clazz clazz = CreateClassUtils.createClazz();
        //调用dao包实现类的insert方法
        int num = manageClazzDao.insert(clazz);
        System.out.println(num == 0?"插入失败":"插入成功");
    }

    @Override
    public void deleteClazz() {
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        System.out.print("请输入要删除的班级号: ");
        int classno = scanner.nextInt();

        //调用dao包实现类的delete方法
        int num =manageClazzDao.delete(classno);
        System.out.println(num == 0?"删除失败":"删除成功");
    }
    //--------------------------------------------------------------------------------
    //关于课程操作
    @Override
    public void checkCourseAll() {
        //调用dao包实现类的selectall方法
        List<Course> courseList =manageCourseDao.selectAll();
        if(!courseList.isEmpty()){
            //遍历集合
            for(Course course:courseList){
                System.out.println(course);
            }
        }else{
            System.out.println("未查找数据");
        }
    }

    @Override
    public void checkCourseByCno() {
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        System.out.print("请输入要查询的课程号: ");
        int cno = scanner.nextInt();

        //调用dao包实现类的selectByCno方法
        Course course =manageCourseDao.selectByCno(cno);
        if(course!=null){
            System.out.println(course);
        }else{
            System.out.println("未查找数据");
        }
    }


    @Override
    public void updateCourseByCno() {
        //创建Course对象
        Course course = CreateClassUtils.createCourse();
        //调用dao包实现类的update方法
        int num = manageCourseDao.update(course);
        System.out.println(num == 0?"修改失败":"修改成功");
    }

    @Override
    public void insertCourse() {
        //创建Course对象
        Course course = CreateClassUtils.createCourse();
        //调用dao包实现类的insert方法
        int num = manageCourseDao.insert(course);
        System.out.println(num == 0?"插入失败":"插入成功");
    }

    @Override
    public void deleteCourse() {
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        System.out.print("请输入要删除的课程号: ");
        int cno = scanner.nextInt();

        //调用dao包实现类的delete方法
        int num =manageCourseDao.delete(cno);
        System.out.println(num == 0?"删除失败":"删除成功");
    }
    //--------------------------------------------------------------------------------
    //关于教师操作
    @Override
    public void checkTeacherAll() {
        //调用dao包实现类的selectall方法
        List<Teacher> teacherList =manageTeacherDao.selectAll();
        if(!teacherList.isEmpty()){
            //遍历集合
            for(Teacher teacher:teacherList){
                System.out.println(teacher);
            }
        }else{
            System.out.println("未查找数据");
        }
    }

    @Override
    public void checkTeacherByTno() {
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        System.out.print("请输入要查询的教师号: ");
        int tno = scanner.nextInt();

        //调用dao包实现类的selectByTno方法
        Teacher teacher =manageTeacherDao.selectByTno(tno);
        if(teacher!=null){
            System.out.println(teacher);
        }else{
            System.out.println("未查找数据");
        }
    }

    @Override
    public void updateTeacher() {
        //创建Teacher对象
        Teacher teacher = CreateClassUtils.createTeacherAll();
        //调用dao包实现类的update方法
        int num = manageTeacherDao.update(teacher);
        System.out.println(num == 0?"修改失败":"修改成功");
    }

    @Override
    public void deleteTeacher() {
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        System.out.print("请输入要删除的教师号: ");
        int tno = scanner.nextInt();

        //调用dao包实现类的delete方法
        int num =manageTeacherDao.delete(tno);
        System.out.println(num == 0?"删除失败":"删除成功");
    }

    @Override
    public void insertTeaher() {
        //创建Course对象
        Teacher teacher = CreateClassUtils.createTeacher();
        //调用dao包实现类的insert方法
        int num = manageTeacherDao.insert(teacher);
        System.out.println(num == 0?"插入失败":"插入成功");
    }
    //--------------------------------------------------------------------------------
    //关于学生操作
    @Override
    public void checkStudentAll() {
        //调用dao包实现类的selectall方法
        List<Student> studentList =manageStudentDao.selectAll();
        if(!studentList.isEmpty()){
            //遍历集合
            for(Student student:studentList){
                System.out.println(student);
            }
        }else{
            System.out.println("未查找数据");
        }
    }

    @Override
    public void checkStudentBySno() {
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        System.out.print("请输入要查询的学号: ");
        int sno = scanner.nextInt();

        //调用dao包实现类的selectBySno方法
        Student student =manageStudentDao.selectBySno(sno);
        if(student!=null){
            System.out.println(student);
        }else{
            System.out.println("未查找数据");
        }
    }

    @Override
    public void insertStudent() {
        //创建Student对象
        Student student = CreateClassUtils.createStudent();
        //调用dao包实现类的insert方法
        int num = manageStudentDao.insert(student);
        System.out.println(num == 0?"插入失败":"插入成功");
    }

    @Override
    public void updateStudent() {
        //创建Teacher对象
        Student student = CreateClassUtils.createStudentAll();
        //调用dao包实现类的update方法
        int num = manageStudentDao.update(student);
        System.out.println(num == 0?"修改失败":"修改成功");
    }

    @Override
    public void deleteStudent() {
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        System.out.print("请输入要删除的学号: ");
        int sno = scanner.nextInt();

        //调用dao包实现类的delete方法
        int num =manageStudentDao.delete(sno);
        System.out.println(num == 0?"删除失败":"删除成功");
    }
    //--------------------------------------------------------------------------------
    //关于成绩操作

    @Override
    public void checkScoreAll() {
        //调用dao包实现类的selectall方法
        List<Score> scoreList =manageScoreDao.selectAll();
        if(!scoreList.isEmpty()){
            //遍历集合
            for(Score score:scoreList){
                System.out.println(score);
            }
        }else{
            System.out.println("未查找数据");
        }
    }

    @Override
    public void checkScoreBySno() {
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        System.out.print("请输入要查询的学号: ");
        int sno = scanner.nextInt();

        //调用dao包实现类的selectBySno方法
        List<Score> scoreList =manageScoreDao.selectBySno(sno);
        if(!scoreList.isEmpty()){
            //遍历集合
            for(Score score:scoreList){
                System.out.println(score);
            }
        }else{
            System.out.println("未查找数据");
        }
    }

    @Override
    public void checkScoreByClassno() {
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        System.out.print("请输入要查询的班级号: ");
        int classno = scanner.nextInt();

        //调用dao包实现类的selectBySno方法
        List<Score> scoreList =manageScoreDao.selectByClassno(classno);
        if(!scoreList.isEmpty()){
            //遍历集合
            for(Score score:scoreList){
                System.out.println(score);
            }
        }else{
            System.out.println("未查找数据");
        }
    }

    @Override
    public void checkScoreByCno() {
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        System.out.print("请输入要查询的课程号: ");
        int cno = scanner.nextInt();

        //调用dao包实现类的selectBySno方法
        List<Score> scoreList =manageScoreDao.selectBycno(cno);
        if(!scoreList.isEmpty()){
            //遍历集合
            for(Score score:scoreList){
                System.out.println(score);
            }
        }else{
            System.out.println("未查找数据");
        }
    }

    @Override
    public void checkScoreByClassnoCno() {
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        System.out.print("请输入要查询的班级号: ");
        int classno = scanner.nextInt();
        System.out.print("请输入要查询的课程号: ");
        int cno = scanner.nextInt();

        //调用dao包实现类的selectBySno方法
        List<Score> scoreList =manageScoreDao.selectByClassnoCno(classno,cno);
        if(!scoreList.isEmpty()){
            //遍历集合
            for(Score score:scoreList){
                System.out.println(score);
            }
        }else{
            System.out.println("未查找数据");
        }
    }
/**
 * @author liuziyang
 * @data 2024-03-09-8:18
 */
}

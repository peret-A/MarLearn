package com.bdqn.service;

public interface ManageTransaction {
/**
 * @author liuziyang
 * @data 2024-03-08-15:10
 */
//--------------------------------------------------------------------------------
//关于班级的操作
    //查看所有班级信息
    public void checkClazzAll();
    //查看指定班级信息
    public void checkClazzByClassno();
    //修改指定班级信息
    public void updateClazz();
    //添加班级信息
    public void insertClazz();
    //删除指定班级信息
    public void deleteClazz();


//--------------------------------------------------------------------------------
//关于课程的操作
    //查看所有课程信息
    public void checkCourseAll();
    //查看指定课程信息
    public void checkCourseByCno();
    //修改指定课程信息
    public void updateCourseByCno();
    //添加课程信息
    public void insertCourse();
    //删除指定课程信息
    public void deleteCourse();
//--------------------------------------------------------------------------------
    //关于教师操作
    //查看所有老师信息
    public void checkTeacherAll();
    //查看指定老师信息
    public void checkTeacherByTno();
    //修改指定老师信息
    public void updateTeacher();
    //删除指定老师信息
    public void deleteTeacher();
    //添加老师信息
    public void insertTeaher();
//--------------------------------------------------------------------------------
    //关于学生操作
    //查看所有学生信息
    public void checkStudentAll();
    //查看指定学生信息
    public void checkStudentBySno();
    //添加学生信息
    public void insertStudent();
    //修改指定学生信息
    public void updateStudent();
    //删除指定学生信息
    public void deleteStudent();
//--------------------------------------------------------------------------------
    //关于成绩操作
    //查看所有学生成绩信息
    public void checkScoreAll();
    //查看指定学生成绩信息
    public void checkScoreBySno();
    //查看指定班级所有学生成绩信息
    public void checkScoreByClassno();
    //查看所有班级指定科目成绩信息
    public void checkScoreByCno();
    //查看指定班级指定科目成绩信息
    public void checkScoreByClassnoCno();
}

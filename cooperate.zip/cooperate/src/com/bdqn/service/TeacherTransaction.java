package com.bdqn.service;

import com.bdqn.entity.Teacher;

public interface TeacherTransaction {
/**
 * @author liuziyang
 * @data 2024-03-08-15:10
 */
    //查看自己的信息
    public void check(Teacher teacher);
    //修改自己的信息
    public void update(Teacher teacher);
    //删除自己的信息
    public void delete(Teacher teacher);
    //



    //查看自己班级所有学生信息
    public void checkStudentAll(Teacher teacher);
    //查看自己班级指定学生信息
    public void checkStudentBySno(Teacher teacher);
    //添加自己班级学生信息
    public void insertStudent(Teacher teacher);
    //修改自己班级指定学生信息
    public void updateStudent(Teacher teacher);
    //删除自己班级指定学生信息
    public void deleteStudent(Teacher teacher);
    //
    //查看自己班级所有学生所有科目成绩信息
    public void checkScoreAll(Teacher teacher);
    //查看自己班级所有学生指定科目成绩信息
    public void checkScoreByCno(Teacher teacher);
    //查看自己班级指定学生所有科目成绩信息
    public void checkScoreBySno(Teacher teacher);
    //查看自己班级指定学生指定科目成绩信息
    public void checkScoreBySnoCno(Teacher teacher);
}

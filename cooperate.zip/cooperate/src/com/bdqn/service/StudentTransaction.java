package com.bdqn.service;

import com.bdqn.entity.Student;

public interface StudentTransaction {
/**
 * @author liuziyang
 * @data 2024-03-08-15:10
 */
//--------------------------------------------------------------------------------
    //关于自己操作
    //查看自己的信息
    public void check(Student student);
    //修改自己的信息
    public void update(Student student);
    //删除自己的信息
    public void delete(Student student);
    //--------------------------------------------------------------------------------
    //关于成绩操作
    //查看自己所有科目成绩信息
    public void checkScoreAll(Student student);
    //查看自己指定科目成绩信息
    public void checkScoreBycno(Student student);
    //查看自己班级所有学生所有科目成绩信息
    public void checkScoreByClassno(Student student);
    //查看自己班级所有学生指定科目成绩信息
    public void checkScoreByClassnoCno(Student student);
    //查看自己班级指定学生所有科目成绩信息
    public void checkScoreBySno(Student student);
    //查看自己班级指定学生指定科目成绩信息
    public void checkScoreBySnoCno(Student student);
}

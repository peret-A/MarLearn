package com.bdqn.dao;

import com.bdqn.entity.Score;
import com.bdqn.entity.Student;

import java.util.List;

public interface StudentDao {
/**
 * @author liuziyang
 * @data 2024-03-08-19:21
 */
    //查看自己的信息 通过学号
    public Student select(Student student);
    //修改自己的信息
    public int update(Student student);
    //删除自己的信息 通过学号
    public int delete(Student student);

    //--------------------------------------------------------------------------
    //操作成绩
    //查看自己所有科目成绩信息
    public List<Score> checkScoreAll(Student student);
    //查看自己指定科目成绩信息
    public Score checkScoreByCno(Student student,int cno);
    //查看自己班级所有学生所有科目成绩信息
    public List<Score> checkClassScoreByClassno(Student student);
    //查看自己班级所有学生指定科目成绩信息
    public List<Score> checkClassScoreByCno(Student student,int cno);
    //查看自己班级指定学生所有科目成绩信息
    public List<Score> checkOtherScoreBySno(Student student,int sno);
    //查看自己班级指定学生指定科目成绩信息
    public Score checkOtherScoreBySnoCno(Student student,int sno,int cno);
}

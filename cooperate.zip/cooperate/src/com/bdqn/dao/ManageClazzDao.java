package com.bdqn.dao;

import com.bdqn.entity.Clazz;

import java.util.List;

public interface ManageClazzDao {
/**
 * @author liuziyang
 * @data 2024-03-08-19:02
 */
    //查看所有班级信息
    public List<Clazz> selectAll();
    //查看指定班级信息 通过班级编号
    public Clazz selectByClassno(int classno);
    //修改指定班级信息
    public int update(Clazz clazz);
    //添加班级信息
    public int insert(Clazz clazz);
    //删除指定班级信息
    public int delete(int classno);
}

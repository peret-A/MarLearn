package com.bdqn.dao;

import com.bdqn.entity.Score;
import com.bdqn.entity.Student;
import com.bdqn.entity.Teacher;

import java.util.List;

public interface TeacherStudentDao {
/**
 * @author liuziyang
 * @data 2024-03-08-19:01
 */
    //查看自己班级所有学生信息 通过教师编号
    public List<Student> selectStudentAll(Teacher teacher);
    //查看自己班级指定学生信息 通过学号
    public Student selectStudentBySno(Teacher teacher,int sno);
    //添加自己班级学生信息
    public int insertStudent(Teacher teacher,Student student);
    //修改自己班级指定学生信息
    public int updateStudent(Teacher teacher,Student student);
    //删除自己班级指定学生信息 通过学号
    public int deleteStudent(Teacher teacher,int sno);
    //---------------------------------------------------------------------------------------
    //查看自己班级所有学生所有科目成绩信息
    public List<Score> selectScoreAll(Teacher teacher);
    //查看自己班级所有学生指定科目成绩信息
    public List<Score> selectScoreByCno(Teacher teacher,int cno);
    //查看自己班级指定学生所有科目成绩信息 通过学生编号 学号唯一
    public List<Score> selectScoreBySno(Teacher teacher,int sno);
    //查看自己班级指定学生指定科目成绩信息 通过学生编号，课程编号
    public Score selectScoreByTnoSnoCno(Teacher teacher,int sno,int cno);
}

package com.bdqn.dao;

import com.bdqn.entity.Teacher;

public interface TeacherDao {
/**
 * @author liuziyang
 * @data 2024-03-08-19:00
 */
    //查看自己的信息
    public Teacher select(Teacher teacher);
    //修改自己的信息
    public int update(Teacher teacher);
    //删除自己的信息
    public int delete(Teacher teacher);
}

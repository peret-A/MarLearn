package com.bdqn.dao;

import com.bdqn.entity.Score;

import java.util.List;

public interface ManageScoreDao {
/**
 * @author liuziyang
 * @data 2024-03-08-18:43
 */
    //查看所有学生成绩信息
    public List<Score> selectAll();

    //查看指定学生成绩信息 通过学号
    public List<Score> selectBySno(int sno);
    //查看指定班级所有学生成绩信息	通过班级号
    public List<Score> selectByClassno(int classno);
    //查看所有班级指定科目成绩信息 通过课程号
    public List<Score> selectBycno(int cno);
    //查看指定班级指定科目成绩信息 通过班级号 和 课程号
    public List<Score> selectByClassnoCno(int classno,int cno);

}

package com.bdqn.dao;

import com.bdqn.entity.Course;

import java.util.List;

public interface ManageCourseDao {
/**
 * @author liuziyang
 * @data 2024-03-08-18:52
 */
    //查看所有课程信息
    public List<Course> selectAll();
    //查看指定课程信息 通过课程号
    public Course selectByCno(int cno);
    //修改指定课程信息
    public int update(Course course);
    //添加课程信息
    public int insert(Course course);
    //删除指定课程信息 通过课程号
    public int delete(int cno);
}

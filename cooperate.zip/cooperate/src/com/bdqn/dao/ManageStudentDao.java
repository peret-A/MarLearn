package com.bdqn.dao;

import com.bdqn.entity.Student;

import java.util.List;

public interface ManageStudentDao {
/**
 * @author liuziyang
 * @data 2024-03-08-18:37
 */
    //查看所有学生信息
    public List<Student> selectAll();
    //查看指定学生信息 通过学号查询
    public Student selectBySno(int sno);
    //添加学生信息 账号一开始默认学号
    public int insert(Student student);
    //修改指定学生信息
    public int update(Student student);
    //删除指定学生信息 通过学号删除
    public int delete(int sno);
}

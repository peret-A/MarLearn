package com.bdqn.dao;

import com.bdqn.entity.Teacher;

import java.util.List;

public interface ManageTeacherDao {
/**
 * @author liuziyang
 * @data 2024-03-08-18:55
 */
    //查看所有老师信息
    public List<Teacher> selectAll();
    //查看指定老师信息 通过教师编号
    public Teacher selectByTno(int tno);
    //修改指定老师信息
    public int update(Teacher teacher);
    //删除指定老师信息 通过教师编号
    public int delete(int tno);
    //添加老师信息
    public int insert(Teacher teacher);
}

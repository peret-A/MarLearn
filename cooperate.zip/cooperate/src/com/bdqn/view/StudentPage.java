package com.bdqn.view;

import com.bdqn.dao.StudentDao;
import com.bdqn.daoImpl.StudentDaoImpl;
import com.bdqn.entity.Manage;
import com.bdqn.entity.Student;
import com.bdqn.service.StudentTransaction;
import com.bdqn.serviceImpl.StudentTransactionImpl;
import com.bdqn.utils.VerifyUtils;

import java.util.Scanner;

public class StudentPage {
/**
 * @author liuziyang
 * @data 2024-03-08-15:15
 */
private static StudentTransaction studentTransaction =new StudentTransactionImpl();
public static void studentPage(){
    Student student =null;
    //登录
    while (true){
        student = (Student) VerifyUtils.verifyStudent();
        if(student==null){
            System.out.println("用户名或者密码错误");
        }else{
            break;
        }
    }
    //创建scanner对象
    Scanner scanner =new Scanner(System.in);
    int input = 0;
    do{
        //先选择管理的页面
        Mean.studentMean();
        System.out.print("请选择: ");
        input =scanner.nextInt();
        switch (input){
            case 1:studentTransaction.check(student);
                break;
            case 2:studentTransaction.update(student);
                break;
            case 3:studentTransaction.delete(student);
                break;
            case 4:studentTransaction.checkScoreAll(student);
                break;
            case 5:studentTransaction.checkScoreBycno(student);
                break;
            case 6:studentTransaction.checkScoreByClassno(student);
                break;
            case 7:studentTransaction.checkScoreBycno(student);
                break;
            case 8:studentTransaction.checkScoreByClassno(student);
                break;
            case 9:studentTransaction.checkScoreBySnoCno(student);
                break;
            case 0:
                break;
            default:
                System.out.println("选择错误,重新选择");
                break;
        }

    }while (input!=0);
}
}

package com.bdqn.view;

import java.util.Scanner;

public class Test {
/**
 * @author liuziyang
 * @data 2024-03-08-13:57
 */
public static void main(String[] args) {

    //创建Scanner对象
    Scanner scanner =new Scanner(System.in);
    int input = 0;
    do{
        //显示主菜单 用户进行选择
        Mean.mean();
        System.out.print("请选择: ");
        input = scanner.nextInt();
        switch (input){
            case 1:
                Login.login();
                break;
            case 0:
                System.out.println("退出系统");
                break;
            default:
                System.out.println("选择错误,重新选择");
                break;
        }

    }while (input!=0);
}
}

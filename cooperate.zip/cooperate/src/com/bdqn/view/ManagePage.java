package com.bdqn.view;

import com.bdqn.entity.Manage;
import com.bdqn.service.ManageTransaction;
import com.bdqn.serviceImpl.ManageTransactionImpl;
import com.bdqn.utils.VerifyUtils;

import java.util.Scanner;

public class ManagePage {
/**
 * @author liuziyang
 * @data 2024-03-08-15:14
 */
    private static ManageTransaction manageTransaction =new ManageTransactionImpl();
    //管理员页面
    public static void managePage(){
    //登录
     while (true){
         Manage manage = (Manage) VerifyUtils.verifyManage();
         if(manage==null){
             System.out.println("用户名或者密码错误");
         }else{
             break;
         }
     }
    //创建scanner对象
    Scanner scanner =new Scanner(System.in);
    int input = 0;
    do{
        //先选择管理的页面
        Mean.manageMean();
        System.out.print("选择要管理的页面: ");
        input =scanner.nextInt();
        switch (input){
            case 1:manageClassPage();
                break;
            case 2:manageCoursePage();
                break;
            case 3:manageTeacherPage();
                break;
            case 4:manageStudentPage();
                break;
            case 0:
                System.out.println("返回上一级");
                break;
            default:
                System.out.println("选择错误,重新选择");
                break;
        }

    }while (input!=0);
}


    public static void manageClassPage(){
    //创建scanner对象
    Scanner scanner =new Scanner(System.in);
    int input = 0;
    do{
        //先选择管理班级的页面
        //查看所有班级信息
        //查看指定班级信息
        //修改指定班级信息
        //添加班级信息
        //删除指定班级信息
        Mean.manageClassMean();
        System.out.print("请选择: ");
        input =scanner.nextInt();
        switch (input){
            case 1:manageTransaction.checkClazzAll();
                break;
            case 2:manageTransaction.checkClazzByClassno();
                break;
            case 3:manageTransaction.updateClazz();
                break;
            case 4:manageTransaction.insertClazz();
                break;
            case 5:manageTransaction.deleteClazz();
                break;
            case 0:
                break;
            default:
                System.out.println("选择错误,重新选择");
                break;
        }

    }while (input!=0);
}
private static void manageCoursePage() {
    //创建scanner对象
    Scanner scanner =new Scanner(System.in);
    int input = 0;
    do{
        //先选择管理的页面
        Mean.manageCourseMean();
        System.out.print("请选择: ");
        input =scanner.nextInt();
        switch (input){

            case 1:manageTransaction.checkCourseAll(); //查看所有课程信息
                break;

            case 2:manageTransaction.checkCourseByCno();//查看指定课程信息
                break;

            case 3:manageTransaction.updateCourseByCno(); //修改指定课程信息
                break;
            case 4:manageTransaction.insertCourse();//添加课程信息
                break;
            case 5:manageTransaction.deleteCourse();//删除指定课程信息
                break;
            case 0:
                break;
            default:
                System.out.println("选择错误,重新选择");
                break;
        }

    }while (input!=0);
}
public static void manageTeacherPage(){
    //创建scanner对象
    Scanner scanner =new Scanner(System.in);
    int input = 0;
    do{
        //管理的教师页面
        //查看所有老师信息
        //查看指定老师信息
        //修改指定老师信息
        //删除指定老师信息
        //添加老师信息
        Mean.manageTeacherMean();
        System.out.print("请选择: ");
        input =scanner.nextInt();
        switch (input){
            case 1:manageTransaction.checkTeacherAll();
                break;
            case 2:manageTransaction.checkTeacherByTno();
                break;
            case 3:manageTransaction.updateTeacher();
                break;
            case 4:manageTransaction.deleteTeacher();
                break;
            case 5:manageTransaction.insertTeaher();
                break;
            case 0:
                break;
            default:
                System.out.println("选择错误,重新选择");
                break;
        }

    }while (input!=0);
}
public static void manageStudentPage(){
    //创建scanner对象
    Scanner scanner =new Scanner(System.in);
    int input = 0;
    do{
        //管理的学生页面
        //查看所有学生信息
        //查看指定学生信息
        //添加学生信息
        //修改指定学生信息
        //删除指定学生信息


        //查看所有学生成绩信息
        //查看指定学生成绩信息
        //查看指定班级所有学生成绩信息
        //查看所有班级指定科目成绩信息
        //查看指定班级指定科目成绩信息
        Mean.manageStudentMean();
        System.out.print("请选择: ");
        input =scanner.nextInt();
        switch (input){
            case 1:manageTransaction.checkStudentAll();
                break;
            case 2:manageTransaction.checkStudentBySno();
                break;
            case 3:manageTransaction.insertStudent();
                break;
            case 4:manageTransaction.updateStudent();
                break;
            case 5:manageTransaction.deleteStudent();
                break;
            case 6:manageTransaction.checkScoreAll();
                break;
            case 7:manageTransaction.checkScoreBySno();
                break;
            case 8:manageTransaction.checkScoreByClassno();
                break;
            case 9:manageTransaction.checkScoreByCno();
                break;
            case 10:manageTransaction.checkScoreByClassnoCno();
                break;
            case 0:
                break;
            default:
                System.out.println("选择错误,重新选择");
                break;
        }

    }while (input!=0);
}
}

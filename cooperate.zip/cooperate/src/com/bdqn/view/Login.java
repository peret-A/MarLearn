package com.bdqn.view;

import java.util.Scanner;

public class Login {
/**
 * @author liuziyang
 * @data 2024-03-08-15:14
 */
public static void login(){
    //创建scanner对象
    Scanner scanner =new Scanner(System.in);
    int input = 0;
    do{
        //先选择你的身份
        Mean.identityMean();
        System.out.print("选择你的身份: ");
        input =scanner.nextInt();
        switch (input){
            case 1:ManagePage.managePage();
                break;
            case 2:TeacherPage.teacherPage();
                break;
            case 3:StudentPage.studentPage();
                break;
            case 0:
                System.out.println("返回上一级");
                break;
            default:
                System.out.println("选择错误,重新选择");
                break;
        }

    }while (input!=0);
}

}

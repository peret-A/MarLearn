package com.bdqn.view;

import com.bdqn.entity.Manage;
import com.bdqn.entity.Teacher;
import com.bdqn.service.TeacherTransaction;
import com.bdqn.serviceImpl.TeacherTransactionImpl;
import com.bdqn.utils.VerifyUtils;

import java.util.Scanner;

public class TeacherPage {
/**
 * @author liuziyang
 * @data 2024-03-08-15:15
 */
private  static  TeacherTransaction teacherTransaction =new TeacherTransactionImpl();
public static void teacherPage(){
    Teacher teacher = null;
    //登录
    while (true){
        teacher = (Teacher) VerifyUtils.verifyTeacher();
        if(teacher==null){
            System.out.println("用户名或者密码错误");
        }else{
            break;
        }
    }
    //创建scanner对象
    Scanner scanner =new Scanner(System.in);
    int input = 0;
    do{
        //先选择管理的页面
        Mean.teacherMean();
        System.out.print("选择要管理的页面: ");
        input =scanner.nextInt();
        switch (input){
            case 1:teachermanageMeanPage(teacher);
                break;
            case 2:teacherStudentMeanPage(teacher);
                break;
            case 0:
                System.out.println("返回上一级");
                break;
            default:
                System.out.println("选择错误,重新选择");
                break;
        }

    }while (input!=0);
}
public static void teachermanageMeanPage(Teacher teacher){
    //创建scanner对象
    Scanner scanner =new Scanner(System.in);
    int input = 0;
    do{
        //先选择的页面
        Mean.teachermanageMean();
        System.out.print("请选择: ");
        input =scanner.nextInt();
        switch (input){
            case 1:teacherTransaction.check(teacher);
                break;
            case 2:teacherTransaction.update(teacher);
                break;
            case 3:teacherTransaction.delete(teacher);
                break;
            case 0:
                break;
            default:
                System.out.println("选择错误,重新选择");
                break;
        }

    }while (input!=0);
}
public static void teacherStudentMeanPage(Teacher teacher){
    //创建scanner对象
    Scanner scanner =new Scanner(System.in);
    int input = 0;
    do{
        //先选择管理的页面
        Mean.teacherStudentMean();
        System.out.print("请选择: ");
        input =scanner.nextInt();
        switch (input){
            case 1:teacherTransaction.checkStudentAll(teacher);
                break;
            case 2:teacherTransaction.checkStudentBySno(teacher);
                break;
            case 3:teacherTransaction.insertStudent(teacher);
                break;
            case 4:teacherTransaction.updateStudent(teacher);
                break;
            case 5:teacherTransaction.checkScoreAll(teacher);
                break;
            case 6:teacherTransaction.checkScoreByCno(teacher);
                break;
            case 7:teacherTransaction.checkScoreBySno(teacher);
                break;
            case 8:teacherTransaction.checkScoreBySnoCno(teacher);
                break;
            case 0:
                break;
            default:
                System.out.println("选择错误,重新选择");
                break;
        }

    }while (input!=0);
}
}

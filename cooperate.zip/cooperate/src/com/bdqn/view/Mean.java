package com.bdqn.view;

public class Mean {
/**
 * @author liuziyang
 * @data 2024-03-08-13:58
 */
    //定义主菜单
    public static  void mean(){
        System.out.println("-------------------------------------------------------");
        System.out.println("  欢迎来到教务管理系统 ");
        System.out.println("  1. 登录");
        System.out.println("  0. 退出");
        System.out.println("-------------------------------------------------------");
    }

    //选择身份
    public static  void identityMean(){
        System.out.println("-------------------------------------------------------");
        System.out.println("  欢迎来到登录页面 ");
        System.out.println("  1. 管理员");
        System.out.println("  2. 教师");
        System.out.println("  3. 学生");
        System.out.println("  0. 返回上一级");
        System.out.println("-------------------------------------------------------");
    }
    //管理员菜单页面
    public static void manageMean(){
        System.out.println("-------------------------------------------------------");
        System.out.println("  欢迎来到管理员页面 ");
        System.out.println("  1. 进入管理班级信息页面");
        System.out.println("  2. 进入管理课程信息页面");
        System.out.println("  3. 进入管理老师信息页面");
        System.out.println("  4. 进入管理学生信息页面");
        System.out.println("  0. 返回上一级");
        System.out.println("-------------------------------------------------------");
    }
    //进入管理班级页面
    public static void manageClassMean(){
        System.out.println("-------------------------------------------------------");
        System.out.println("  欢迎来到管理班级信息页面 ");
        System.out.println("  1. 查看所有班级信息");
        System.out.println("  2. 查看指定班级信息");
        System.out.println("  3. 修改指定班级信息");
        System.out.println("  4. 添加班级信息");
        System.out.println("  5. 删除指定班级信息");
        System.out.println("  0. 返回上一级");
        System.out.println("-------------------------------------------------------");
    }
    //进入管理课程页面
    public static void manageCourseMean(){
        System.out.println("-------------------------------------------------------");
        System.out.println("  欢迎来到管理课程信息页面 ");
        System.out.println("  1. 查看所有课程信息");
        System.out.println("  2. 查看指定课程信息");
        System.out.println("  3. 修改指定课程信息");
        System.out.println("  4. 添加课程信息");
        System.out.println("  5. 删除指定课程信息");
        System.out.println("  0. 返回上一级");
        System.out.println("-------------------------------------------------------");
    }
    //进入管理教师页面
    public static void manageTeacherMean(){
        System.out.println("-------------------------------------------------------");
        System.out.println("  欢迎来到管理教师信息页面 ");
        System.out.println("  1. 查看所有教师信息");
        System.out.println("  2. 查看指定教师信息");
        System.out.println("  3. 修改指定教师信息");
        System.out.println("  4. 添加教师信息");
        System.out.println("  5. 删除指定教师信息");
        System.out.println("  0. 返回上一级");
        System.out.println("-------------------------------------------------------");
    }
    //进入管理学生页面
    public static void manageStudentMean(){
        System.out.println("-------------------------------------------------------");
        System.out.println("  欢迎来到管理学生信息页面 ");
        System.out.println("  1.  查看所有学生信息");
        System.out.println("  2.  查看指定学生信息");
        System.out.println("  3.  添加学生信息");
        System.out.println("  4.  修改指定学生信息");
        System.out.println("  5.  删除指定学生信息");
        System.out.println("  6.  查看所有学生成绩信息");
        System.out.println("  7.  查看指定学生成绩信息");
        System.out.println("  8.  查看指定班级所有学生成绩信息");
        System.out.println("  9.  查看所有班级指定科目成绩信息");
        System.out.println("  10. 查看指定班级指定科目成绩信息");
        System.out.println("  0.  返回上一级");
        System.out.println("-------------------------------------------------------");
    }
    //教师菜单页面
    public static void teacherMean(){
        System.out.println("-------------------------------------------------------");
        System.out.println("  欢迎来到教师页面 ");
        System.out.println("  1. 进入管理自己信息页面");
        System.out.println("  2. 进入管理学生信息页面");
        System.out.println("  0. 返回上一级");
        System.out.println("-------------------------------------------------------");
    }
    //进入教师管理自己页面
    public static void teachermanageMean(){
        System.out.println("-------------------------------------------------------");
        System.out.println("  欢迎来到管理自己信息页面 ");
        System.out.println("  1.  查看自己的信息");
        System.out.println("  2.  修改自己的信息");
        System.out.println("  3.  删除自己的信息");
        System.out.println("  0.  返回上一级");
        System.out.println("-------------------------------------------------------");
    }
    //进入管理学生页面
    public static void teacherStudentMean(){
        System.out.println("-------------------------------------------------------");
        System.out.println("  欢迎来到管理学生信息页面 ");
        System.out.println("  1.  查看自己班级所有学生信息");
        System.out.println("  2.  查看自己班级指定学生信息");
        System.out.println("  3.  添加自己班级学生信息");
        System.out.println("  4.  修改自己班级指定学生信息");
        System.out.println("  5.  删除自己班级指定学生信息");
        System.out.println("  6.  查看自己班级所有学生所有科目成绩信息");
        System.out.println("  7.  查看自己班级指定学生所有科目成绩信息");
        System.out.println("  8.  查看所有班级指定科目成绩信息");
        System.out.println("  0.  返回上一级");
        System.out.println("-------------------------------------------------------");
    }

    //学生菜单页面
    public static void studentMean(){
        System.out.println("-------------------------------------------------------");
        System.out.println("  欢迎来到学生页面 ");
        System.out.println("  1. 查看自己的信息");
        System.out.println("  2. 修改自己的信息");
        System.out.println("  3. 删除自己的信息");
        System.out.println("  4. 查看自己所有科目成绩信息");
        System.out.println("  5. 查看自己指定科目成绩信息");
        System.out.println("  6. 查看自己班级所有学生所有科目成绩信息");
        System.out.println("  7. 查看自己班级所有学生指定科目成绩信息");
        System.out.println("  8. 查看自己班级指定学生所有科目成绩信息");
        System.out.println("  9. 查看自己班级指定学生指定科目成绩信息");
        System.out.println("  0. 返回上一级");
        System.out.println("-------------------------------------------------------");
    }
}

package com.bdqn.entity;

public class Course {
    private int cno;
    private String cname;
    private int tno;

    public Course() {
    }


    @Override
    public String toString() {
        return "课程{" +
                "课程号=" + cno +
                ", 课程名称='" + cname + '\'' +
                ", 课程教师=" + tno +
                '}';
    }

    public int getCno() {
        return cno;
    }

    public void setCno(int cno) {
        this.cno = cno;
    }

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    public int getTno() {
        return tno;
    }

    public void setTno(int tno) {
        this.tno = tno;
    }

    public Course(int cno, String cname, int tno) {
        this.cno = cno;
        this.cname = cname;
        this.tno = tno;
    }
}

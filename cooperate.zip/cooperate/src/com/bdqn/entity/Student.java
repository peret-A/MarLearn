package com.bdqn.entity;

import java.util.Date;

public class Student {
    private int sno;
    private String sname;
    private String ssex;
    private Date sbirthday;
    private int classno;
    private String username;
    private String password;

    public Student() {
    }



    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }


    public int getSno() {
        return sno;
    }

    public void setSno(int sno) {
        this.sno = sno;
    }

    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

    public String getSsex() {
        return ssex;
    }

    public void setSsex(String ssex) {
        this.ssex = ssex;
    }

    public Date getSbirthday() {
        return sbirthday;
    }

    public void setSbirthday(Date sbirthday) {
        this.sbirthday = sbirthday;
    }

    public Student(String sname, String ssex, Date sbirthday, int classno, String username, String password) {
        this.sname = sname;
        this.ssex = ssex;
        this.sbirthday = sbirthday;
        this.classno = classno;
        this.username = username;
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    public int getClassno() {
        return classno;
    }

    public void setClassno(int classno) {
        this.classno = classno;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "Student{" +
                "sno=" + sno +
                ", sname='" + sname + '\'' +
                ", ssex='" + ssex + '\'' +
                ", sbirthday=" + sbirthday +
                ", classno='" + classno + '\'' +
                '}';
    }
}

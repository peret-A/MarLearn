package com.bdqn.entity;

import java.util.Date;

public class Teacher {
    private int tno;
    private String tname;
    private String tsex;
    private Date tbirthday;
    private String prof;
    private String depart;
    private String username;
    private String password;

    public Teacher() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Teacher(int tno, String tname, String tsex, Date tbirthday, String prof, String depart, String username, String password) {
        this.tno = tno;
        this.tname = tname;
        this.tsex = tsex;
        this.tbirthday = tbirthday;
        this.prof = prof;
        this.depart = depart;
        this.username = username;
        this.password = password;
    }

    public Teacher(String tname, String tsex, Date tbirthday, String prof, String depart) {
        this.tname = tname;
        this.tsex = tsex;
        this.tbirthday = tbirthday;
        this.prof = prof;
        this.depart = depart;
    }

    public Teacher(int tno, String tname, String tsex, Date tbirthday, String prof, String depart, String password) {
        this.tno = tno;
        this.tname = tname;
        this.tsex = tsex;
        this.tbirthday = tbirthday;
        this.prof = prof;
        this.depart = depart;
        this.password = password;
    }

    public int getTno() {
        return tno;
    }

    public void setTno(int tno) {
        this.tno = tno;
    }

    public String getTname() {
        return tname;
    }

    public void setTname(String tname) {
        this.tname = tname;
    }

    public String getTsex() {
        return tsex;
    }

    public void setTsex(String tsex) {
        this.tsex = tsex;
    }

    public Date getTbirthday() {
        return tbirthday;
    }

    public void setTbirthday(Date tbirthday) {
        this.tbirthday = tbirthday;
    }

    public String getProf() {
        return prof;
    }

    public void setProf(String prof) {
        this.prof = prof;
    }

    public String getDepart() {
        return depart;
    }

    public void setDepart(String depart) {
        this.depart = depart;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Teacher(String tname, String tsex, Date tbirthday, String prof, String depart, String username, String password) {
        this.tname = tname;
        this.tsex = tsex;
        this.tbirthday = tbirthday;
        this.prof = prof;
        this.depart = depart;
        this.username = username;
        this.password = password;
    }

    @Override
    public String toString() {
        return "Teacher{" +
                "tno=" + tno +
                ", tname='" + tname + '\'' +
                ", tsex='" + tsex + '\'' +
                ", tbirthday=" + tbirthday +
                ", prof='" + prof + '\'' +
                ", depart='" + depart + '\'' +
                '}';
    }
}

package com.bdqn.entity;

public class Clazz {
    private int  classno;
    private int  tno;
    private String classname;

    public Clazz() {
    }

    @Override
    public String toString() {
        return "Clazz{" +
                "classno=" + classno +
                ", tno=" + tno +
                ", classname='" + classname + '\'' +
                '}';
    }

    public int getClassno() {
        return classno;
    }

    public void setClassno(int classno) {
        this.classno = classno;
    }

    public int getTno() {
        return tno;
    }

    public void setTno(int tno) {
        this.tno = tno;
    }

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    public Clazz(int classno, int tno, String classname) {
        this.classno = classno;
        this.tno = tno;
        this.classname = classname;
    }
}

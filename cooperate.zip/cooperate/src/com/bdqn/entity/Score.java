package com.bdqn.entity;

public class Score {
    private int sno;
    private String con;
    private double degree;

    public Score() {
    }

    public Score(int sno, String con, double degree) {
        this.sno = sno;
        this.con = con;
        this.degree = degree;
    }

    public Score(String con, double degree) {
        this.con = con;
        this.degree = degree;
    }

    public int getSno() {
        return sno;
    }

    public void setSno(int sno) {
        this.sno = sno;
    }

    public String getCon() {
        return con;
    }

    public void setCon(String con) {
        this.con = con;
    }

    public double getDegree() {
        return degree;
    }

    public void setDegree(double degree) {
        this.degree = degree;
    }

    @Override
    public String toString() {
        return "Score{" +
                "sno=" + sno +
                ", con='" + con + '\'' +
                ", degree=" + degree +
                '}';
    }
}

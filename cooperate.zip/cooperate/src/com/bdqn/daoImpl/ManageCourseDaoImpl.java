package com.bdqn.daoImpl;

import com.bdqn.dao.ManageCourseDao;
import com.bdqn.entity.Course;
import com.bdqn.utils.DBUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.List;

public class ManageCourseDaoImpl implements ManageCourseDao {
    /**
     * @author liuziyang
     * @data 2024-03-08-19:31
     */
    //使用Apache已定义的QueryRunner 去调用 update方法 query方法
    QueryRunner queryRunner = new QueryRunner(DBUtils.getDatabase());
    @Override
    public List<Course> selectAll() {
        //定义sql语句
        String sql = "select * from course;";
        //创建BeanListHandler对象
        BeanListHandler<Course> beanHandler = new BeanListHandler<>(Course.class);
        //调用query方法查询
        try {
            return  queryRunner.query(sql,beanHandler);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public Course selectByCno(int cno) {
        //定义sql语句
        String sql = "select * from course where cno = ?;";
        //创建BeanHandler对象
        BeanHandler<Course> beanHandler = new BeanHandler<>(Course.class);
        //调用query方法查询
        try {
            return  queryRunner.query(sql,beanHandler,cno);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public int update(Course course) {
        //定义sql语句
        String sql ="update course set cname = ? , tno = ? where cno = ?;";
        //给占位符赋值
        Object[] args = {course.getCname(),course.getTno(),course.getCno()};
        //调用update方法
        try {
            return  queryRunner.update(sql,args);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public int insert(Course course) {
        //定义sql
        String sql ="insert into course values(?,?,?)";
        //给占位符赋值
        Object[] args = {course.getCno(),course.getCname(),course.getTno()};
        try {
            return  queryRunner.update(sql,args);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public int delete(int cno) {
        //定义sql
        String sql ="delete from course where cno = ?";
        //给占位符赋值 已有
        try {
            return  queryRunner.update(sql,cno);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}

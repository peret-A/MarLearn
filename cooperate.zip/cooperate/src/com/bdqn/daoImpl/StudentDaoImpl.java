package com.bdqn.daoImpl;

import com.bdqn.dao.StudentDao;
import com.bdqn.entity.Score;
import com.bdqn.entity.Student;
import com.bdqn.utils.DBUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.List;

public class StudentDaoImpl implements StudentDao {
    private QueryRunner queryRunner =new QueryRunner(DBUtils.getDatabase());
    //查看自己的信息
    //修改自己的信息
    //删除自己的信息
    @Override
    public Student select(Student student) {
        //定义sql
        String sql = "select * from student where sno = ?;";
        //创建BeanHandler对象
        BeanHandler<Student> beanHandler =new BeanHandler<>(Student.class);
        //给占位符赋值
        //调用query方法
        try {
            return queryRunner.query(sql,beanHandler,student.getSno());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public int update(Student student) {
        //定义sql
        String sql = "update  student set sname = ?,ssex =?, sbirthday =?, classno=? ,username=? ,password=? where sno = ?;";
        //给占位符赋值
        Object[] args = {student.getSname(), student.getSsex(),student.getSbirthday(),student.getClassno(),student.getUsername(),student.getPassword(),student.getSno()};
        //调用update
        try {
            return  queryRunner.update(sql,args);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public int delete(Student student) {
        //定义sql
        String sql = "delete from student where sno = ?;";
        //给占位符赋值
        //调用update
        try {
            return  queryRunner.update(sql,student.getSno());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    //查看自己所有科目成绩信息
    //查看自己指定科目成绩信息
    //查看自己班级所有学生所有科目成绩信息
    //查看自己班级所有学生指定科目成绩信息
    //查看自己班级指定学生所有科目成绩信息
    //查看自己班级指定学生指定科目成绩信息
    @Override
    public List<Score> checkScoreAll(Student student) {
        //定义sql
        String sql = "select * from score where sno = ?;";
        //创建BeanHandler对象
        BeanListHandler<Score> beanListHandler =new BeanListHandler<>(Score.class);
        //给占位符赋值
        //调用query方法
        try {
            return queryRunner.query(sql,beanListHandler,student.getSno());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Score checkScoreByCno(Student student, int cno) {
        //定义sql
        String sql = "select * from score where sno = ? and cno = ?;";
        //创建BeanHandler对象
        BeanHandler<Score> beanHandler =new BeanHandler<>(Score.class);
        //给占位符赋值
        //调用query方法
        try {
            return queryRunner.query(sql,beanHandler,student.getSno(),cno);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<Score> checkClassScoreByClassno(Student student) {
        //定义sql
        String sql = "SELECT * FROM score WHERE sno IN (SELECT sno FROM student WHERE classno = (SELECT classno FROM student WHERE sno = ?)  ) ;";
        //创建BeanHandler对象
        BeanListHandler<Score> beanListHandler =new BeanListHandler<>(Score.class);
        //给占位符赋值
        //调用query方法
        try {
            return queryRunner.query(sql,beanListHandler,student.getSno());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<Score> checkClassScoreByCno(Student student,int cno) {
        //定义sql
        String sql = "SELECT * FROM score WHERE sno IN (SELECT sno FROM student WHERE classno = (SELECT classno FROM student WHERE sno = ?) ) and cno = ? ;";
        //创建BeanHandler对象
        BeanListHandler<Score> beanListHandler =new BeanListHandler<>(Score.class);
        //给占位符赋值
        Object[] args = {student.getSno(),cno};
        //调用query方法
        try {
            return queryRunner.query(sql,beanListHandler,args);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<Score> checkOtherScoreBySno(Student student, int sno) {
        //定义sql
        String sql = "SELECT * FROM score WHERE sno IN (SELECT sno FROM student WHERE classno = (SELECT classno FROM student WHERE sno = ?) ) and sno = ? ;";
        //创建BeanHandler对象
        BeanListHandler<Score> beanListHandler =new BeanListHandler<>(Score.class);
        //给占位符赋值
        Object[] args = {student.getSno(),sno};
        //调用query方法
        try {
            return queryRunner.query(sql,beanListHandler,args);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Score checkOtherScoreBySnoCno(Student student, int sno, int cno) {
        //定义sql
        String sql = "SELECT * FROM score WHERE sno IN (SELECT sno FROM student WHERE classno = (SELECT classno FROM student WHERE sno = ?) ) and sno = ? and cno = ?;";
        //创建BeanHandler对象
        BeanHandler<Score> beanHandler =new BeanHandler<>(Score.class);
        //给占位符赋值
        Object[] args = {student.getSno(),sno,cno};
        //调用query方法
        try {
            return queryRunner.query(sql,beanHandler,args);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

/**
 * @author liuziyang
 * @data 2024-03-09-11:09
 */
}

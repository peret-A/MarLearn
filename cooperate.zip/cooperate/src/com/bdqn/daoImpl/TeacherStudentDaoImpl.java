package com.bdqn.daoImpl;

import com.bdqn.dao.TeacherStudentDao;
import com.bdqn.entity.Score;
import com.bdqn.entity.Student;
import com.bdqn.entity.Teacher;
import com.bdqn.utils.DBUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.List;

public class TeacherStudentDaoImpl implements TeacherStudentDao {
    private QueryRunner queryRunner =new QueryRunner(DBUtils.getDatabase());
    @Override
    public List<Student> selectStudentAll(Teacher teacher) {
        //定义sql
        String sql = "SELECT * FROM student WHERE classno = (SELECT classno FROM clazz WHERE tno = ?);";
        //创建BeanHandler对象
        BeanListHandler<Student> beanHandler =new BeanListHandler<>(Student.class);
        //给占位符赋值
        //调用query方法
        try {
            return queryRunner.query(sql,beanHandler,teacher.getTno());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Student selectStudentBySno(Teacher teacher,int sno) {
        //定义sql
        String sql = "SELECT * FROM student WHERE classno = (SELECT classno FROM clazz WHERE tno = ?) and sno = ?;";
        //创建BeanHandler对象
        BeanHandler<Student> beanHandler =new BeanHandler<>(Student.class);
        //给占位符赋值
        Object[] args = {teacher.getTno(),sno};
        //调用query方法
        try {
            return queryRunner.query(sql,beanHandler,args);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public int insertStudent(Teacher teacher,Student student) {
        //定义sql
        String sql = "insert into student(sname,ssex,sbirthday,classno,username,password) values(?,?,?,?,?);";
        //给占位符赋值
        Object[] args = {student.getSname(), student.getSsex(),student.getSbirthday(),student.getClassno(),student.getUsername(),student.getPassword()};
        //调用update
        try {
            return  queryRunner.update(sql,args);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public int updateStudent(Teacher teacher,Student student) {
        //定义sql
        String sql = "update  student set sname = ?,ssex =?, sbirthday =?, classno=? ,username=? ,password=? where sno = ?;";
        //给占位符赋值
        Object[] args = {student.getSname(), student.getSsex(),student.getSbirthday(),student.getClassno(),student.getUsername(),student.getPassword(),student.getSno()};
        //调用update
        try {
            return  queryRunner.update(sql,args);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public int deleteStudent(Teacher teacher,int sno) {
        //定义sql
        String sql = "delete from student where classno = (SELECT classno FROM clazz WHERE tno = ?) and sno = ?";
        //给占位符赋值
        Object[] args = {teacher.getTno(),sno};
        //调用update
        try {
            return  queryRunner.update(sql,args);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
//-----------------------------------------------------------------------------
    @Override
    public List<Score> selectScoreAll(Teacher teacher) {
        //定义sql
        String sql ="SELECT * FROM score WHERE sno IN (SELECT sno FROM student WHERE classno = (SELECT classno FROM clazz WHERE tno = ?));";
        //创建BeanHandler对象
        BeanListHandler<Score> beanListHandler =new BeanListHandler<>(Score.class);
        //给占位符赋值
        //调用query方法
        try {
            return queryRunner.query(sql,beanListHandler,teacher.getTno());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<Score> selectScoreByCno(Teacher teacher, int cno) {
        //定义sql
        String sql ="SELECT * FROM score WHERE sno IN (SELECT sno FROM student WHERE classno = (SELECT classno FROM clazz WHERE tno = ?)) and cno = ?;";
        //创建BeanHandler对象
        BeanListHandler<Score> beanListHandler =new BeanListHandler<>(Score.class);
        //给占位符赋值
        Object[] args = {teacher.getTno(),cno};
        //调用query方法
        try {
            return queryRunner.query(sql,beanListHandler,args);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<Score> selectScoreBySno(Teacher teacher,int sno) {
        //定义sql
        String sql ="SELECT * FROM score WHERE sno IN (SELECT sno FROM student WHERE classno = (SELECT classno FROM clazz WHERE tno = ?)) and sno = ?;";
        //创建BeanHandler对象
        BeanListHandler<Score> beanListHandler =new BeanListHandler<>(Score.class);
        //给占位符赋值
        Object[] args = {teacher.getTno(),sno};
        //调用query方法
        try {
            return queryRunner.query(sql,beanListHandler,args);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Score selectScoreByTnoSnoCno(Teacher teacher,int sno, int cno) {
        //定义sql
        String sql ="SELECT * FROM score WHERE sno IN (SELECT sno FROM student WHERE classno = (SELECT classno FROM clazz WHERE tno = ?)) and sno = ? and cno = ?;";
        //创建BeanHandler对象
        BeanHandler<Score> beanHandler =new BeanHandler<>(Score.class);
        //给占位符赋值
        Object[] args = {teacher.getTno(),sno,cno};
        //调用query方法
        try {
            return queryRunner.query(sql,beanHandler,args);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
/**
 * @author liuziyang
 * @data 2024-03-09-11:10
 */
}

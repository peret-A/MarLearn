package com.bdqn.daoImpl;

import com.bdqn.dao.ManageStudentDao;
import com.bdqn.entity.Student;
import com.bdqn.utils.DBUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.List;

public class ManageStudentDaoImpl implements ManageStudentDao {
    private  QueryRunner queryRunner =new QueryRunner(DBUtils.getDatabase());
    @Override
    public List<Student> selectAll() {
        //定义sql
        String sql = "select * from student";
        //创建BeanHanler
        BeanListHandler<Student> beanListHandler =new BeanListHandler(Student.class);
        //调用query
        try {
            return  queryRunner.query(sql,beanListHandler);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Student selectBySno(int sno) {
        //定义sql
        String sql = "select * from student where sno = ?";
        //创建BeanHanler
        BeanHandler<Student> beanListHandler =new BeanHandler(Student.class);
        //给占位符赋值
        //调用query
        try {
            return  queryRunner.query(sql,beanListHandler,sno);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public int insert(Student student) {
        //定义sql
        String sql = "insert into student(sname,ssex,sbirthday,classno,username,password) values(?,?,?,?,?);";
        //给占位符赋值
        Object[] args = {student.getSname(), student.getSsex(),student.getSbirthday(),student.getClassno(),student.getUsername(),student.getPassword()};
        //调用update
        try {
            return  queryRunner.update(sql,args);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public int update(Student student) {
        //定义sql
        String sql = "update  student set sname = ?,ssex =?, sbirthday =?, classno=? ,username=? ,password=? where sno = ?;";
        //给占位符赋值
        Object[] args = {student.getSname(), student.getSsex(),student.getSbirthday(),student.getClassno(),student.getUsername(),student.getPassword(),student.getSno()};
        //调用update
        try {
            return  queryRunner.update(sql,args);
        } catch (SQLException e) {
            throw new RuntimeException(e);
    }
    }

    @Override
    public int delete(int sno) {
        //定义sql
        String sql = "delete from student where sno = ?";
        //给占位符赋值
        //调用update
        try {
            return  queryRunner.update(sql,sno);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
/**
 * @author liuziyang
 * @data 2024-03-09-8:48
 */
}

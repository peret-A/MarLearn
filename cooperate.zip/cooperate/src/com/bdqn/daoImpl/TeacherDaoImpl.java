package com.bdqn.daoImpl;

import com.bdqn.dao.TeacherDao;
import com.bdqn.entity.Student;
import com.bdqn.entity.Teacher;
import com.bdqn.utils.DBUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import java.sql.SQLException;

public class TeacherDaoImpl implements TeacherDao {
    private QueryRunner queryRunner =new QueryRunner(DBUtils.getDatabase());
    @Override
    public Teacher select(Teacher teacher) {
        //定义sql
        String sql = "select * from teacher where tno = ?;";
        //创建BeanHandler对象
        BeanHandler<Teacher> beanHandler =new BeanHandler<>(Teacher.class);
        //给占位符赋值
        //调用query方法
        try {
            return queryRunner.query(sql,beanHandler,teacher.getTno());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public int update(Teacher teacher) {
        //定义sql
        String sql = "update  teacher set tname = ?,tsex =?, tbirthday =?, prof=? ,depart=? ,username=?,password=? where tno = ?;";
        //给占位符赋值
        Object[] args = {teacher.getTname(),teacher.getTsex(),teacher.getTbirthday(),teacher.getProf(),teacher.getDepart(),teacher.getUsername(),teacher.getPassword(),teacher.getTno()};
        //调用update
        try {
            return  queryRunner.update(sql,args);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public int delete(Teacher teacher) {
        //定义sql
        String sql = "delete from teacher where tno = ?;";
        //给占位符赋值
        //调用update
        try {
            return  queryRunner.update(sql,teacher.getTno());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
/**
 * @author liuziyang
 * @data 2024-03-09-11:10
 */
}

package com.bdqn.daoImpl;

import com.bdqn.dao.ManageScoreDao;
import com.bdqn.entity.Score;
import com.bdqn.utils.DBUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.List;

public class ManageScoreDaoImpl implements ManageScoreDao {
    /**
     * @author liuziyang
     * @data 2024-03-08-20:01
     */
    //使用apache的工具类QueryRunner
    QueryRunner queryRunner =new QueryRunner(DBUtils.getDatabase());
    @Override
    public List<Score> selectAll() {
        //定义sql
        String sql ="select * from score;";
        //创建BeanHandler
        BeanListHandler<Score> beanHandler =new BeanListHandler<>(Score.class);
        //调用query
        try {
            return  queryRunner.query(sql,beanHandler);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<Score> selectBySno(int sno) {
        //定义sql
        String sql ="select * from score where sno = ?;";
        //创建BeanHandler
        BeanListHandler<Score> beanListHandler =new BeanListHandler<>(Score.class);
        //调用query
        try {
            return  queryRunner.query(sql,beanListHandler,sno);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<Score> selectByClassno(int classno) {
        //定义sql
        String sql ="\n" +
                "SELECT sc.* FROM score sc JOIN student st ON sc.`sno`=st.`sno` WHERE st.`classno` = ?;";
        //创建BeanHandler
        BeanListHandler<Score> beanHandler =new BeanListHandler<>(Score.class);
        //调用query
        try {
            return  queryRunner.query(sql,beanHandler,classno);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<Score> selectBycno(int cno) {
        //定义sql
        String sql ="select * from score where cno = cno;";
        //创建BeanHandler
        BeanListHandler<Score> beanHandler =new BeanListHandler<>(Score.class);
        //调用query
        try {
            return  queryRunner.query(sql,beanHandler,cno);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<Score> selectByClassnoCno(int classno, int cno) {

        //定义sql
        String sql ="\n" +
                "SELECT sc.* FROM score sc JOIN student st ON sc.`sno`=st.`sno` WHERE st.`classno` = ? and sc.`cno` = ?;";
        //创建BeanHandler
        BeanListHandler<Score> beanHandler =new BeanListHandler<>(Score.class);
        Object[] args = {classno,cno};
        //调用query
        try {
            return  queryRunner.query(sql,beanHandler,args);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}

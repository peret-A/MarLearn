package com.bdqn.daoImpl;

import com.bdqn.dao.ManageClazzDao;
import com.bdqn.entity.Clazz;
import com.bdqn.entity.Course;
import com.bdqn.utils.DBUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.List;

public class ManageClazzDaoImpl implements ManageClazzDao {
    //使用Apache已定义的QueryRunner 去调用 update方法 query方法
    QueryRunner queryRunner = new QueryRunner(DBUtils.getDatabase());
    @Override
    public List<Clazz> selectAll() {
        //定义sql语句
        String sql = "select * from clazz;";
        //创建BeanListHandler对象
        BeanListHandler<Clazz> beanHandler = new BeanListHandler<>(Clazz.class);
        //调用query方法查询
        try {
            return  queryRunner.query(sql,beanHandler);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Clazz selectByClassno(int clazzno) {
        //定义sql语句
        String sql = "select * from clazz where classno = ?;";
        //创建BeanHandler对象
        BeanHandler<Clazz> beanHandler = new BeanHandler<>(Clazz.class);
        //调用query方法查询
        try {
            return  queryRunner.query(sql,beanHandler,clazzno);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public int update(Clazz clazz) {
        //定义sql语句
        String sql ="update clazz set tno = ? , classname = ? where classno = ?;";
        //给占位符赋值
        Object[] args = {clazz.getTno(),clazz.getClassname(),clazz.getClassno()};
        //调用update方法
        try {
            return  queryRunner.update(sql,args);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public int insert(Clazz clazz) {
        //定义sql
        String sql ="insert into clazz values(?,?,?)";
        //给占位符赋值
        Object[] args = {clazz.getClassno(),clazz.getTno(),clazz.getClassname()};
        try {
            return  queryRunner.update(sql,args);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public int delete(int classno) {
        //定义sql
        String sql ="delete from clazz where classno = ?";
        //给占位符赋值 已有
        try {
            return  queryRunner.update(sql,classno);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
/**
 * @author liuziyang
 * @data 2024-03-09-9:04
 */

}
